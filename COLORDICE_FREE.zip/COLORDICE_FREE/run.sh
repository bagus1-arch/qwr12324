python main.py
sleep 5
sh run.sh